﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace Waz
{
    public partial class Form1 : Form
    {
        private Bitmap Rysunek = new Bitmap(400, 400);
        private static int iloscPol = 20;
        private int szerokoscPola, wysokoscPola;
        private Random rand = new Random();
        private enum kierunek { Prawo = 1, Lewo = 2, Gora = 3, Dol = 4 };
        private kierunek biezacyKierunek = kierunek.Prawo;
        private int[] mysz = new int[2];
        private struct Wezyk
        {
            public int polX;
            public int polY;
            
            public Wezyk(int p1, int p2)
            {
                polX = p1;
                polY = p2;
            }
        }
        private Wezyk[] waz = new Wezyk[iloscPol*iloscPol];

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Parent = pictureBox1;
            label1.BackColor = Color.Transparent;
            label1.BringToFront();
            label1.ForeColor = Color.Gray;
            label1.Text = "0";
            label1.Location = new Point(12, 366);
            szerokoscPola = Rysunek.Width / iloscPol;
            wysokoscPola = Rysunek.Height / iloscPol;
            WszystkoOdNowa();
        }

        private void WszystkoOdNowa()
        {
            biezacyKierunek = kierunek.Prawo;
            NowyWaz(waz);
            mysz = LosujMysz(waz);
            timer1.Enabled = true;
        }

        private int[] LosujMysz(Wezyk[] wezyk)
        {
            int[] pol = new int[2];
            bool polWeza;
            do
            {
                polWeza = false;
                pol[0] = rand.Next(Rysunek.Width)/szerokoscPola*szerokoscPola;
                pol[1] = rand.Next(Rysunek.Height)/wysokoscPola*wysokoscPola;
                for (int i = 0; i < DlugoscWeza(wezyk); i++)
                {
                    if ((pol[0] == wezyk[i].polX) && (pol[1] == wezyk[i].polY))
                        polWeza = true;
                }
            } while (polWeza == true);
            return pol;
        }

        private void NowyWaz(Wezyk[] wezyk)
        {
            for (int i = 0; i < wezyk.Length; i++)
            {
                if (i < 3)
                    wezyk[i] = new Wezyk(((Rysunek.Width / 2) - (i * szerokoscPola)), (Rysunek.Height/2));
                else
                    wezyk[i] = new Wezyk(-1, -1);
            }
        }

        private int DlugoscWeza(Wezyk[] wezyk)
        {
            int dlugosc = 0;
            for (int i = 0; i < wezyk.Length; i++)
            {
                if ((wezyk[i].polX == -1) && (wezyk[i].polY == -1))
                {
                    return dlugosc;
                }
                dlugosc++;
            }
            return dlugosc;
        }

        private void RuchWeza(Wezyk[] wezyk)
        {
            for (int i = DlugoscWeza(wezyk) - 1; i > 0 ; i--)
            {
                wezyk[i].polX = wezyk[i - 1].polX;
                wezyk[i].polY = wezyk[i - 1].polY;
            }
            if (biezacyKierunek == kierunek.Prawo)
                wezyk[0].polX += szerokoscPola;
            else if (biezacyKierunek == kierunek.Lewo)
                wezyk[0].polX -= szerokoscPola;
            else if (biezacyKierunek == kierunek.Gora)
                wezyk[0].polY -= wysokoscPola;
            else
                wezyk[0].polY += wysokoscPola;
            if ((wezyk[0].polX == mysz[0]) && (wezyk[0].polY == mysz[1]))
            {
                mysz = LosujMysz(wezyk);
                wezyk[DlugoscWeza(wezyk)].polX = wezyk[DlugoscWeza(wezyk) - 1].polX;
                wezyk[DlugoscWeza(wezyk)-1].polY = wezyk[DlugoscWeza(wezyk) - 2].polY;
            }
            //Jezeli sciana BOOM
            if ((wezyk[0].polX < 0) || (wezyk[0].polX >= Rysunek.Width)
                || (wezyk[0].polY < 0) || (wezyk[0].polY >= Rysunek.Height))
            {
                timer1.Enabled = false;
                MessageBox.Show("BOOM\nTwoj wynik to: " + ((DlugoscWeza(waz) - 3) * 10));
                WszystkoOdNowa();
            }
            //Jezeli zje swoj ogon
            for (int i = 1; i < DlugoscWeza(wezyk); i++)
            {
                if ((wezyk[0].polX == wezyk[i].polX) && (wezyk[0].polY == wezyk[i].polY))
                {
                    timer1.Enabled = false;
                    MessageBox.Show("BOOM\nTwoj wynik to: " + ((DlugoscWeza(waz) - 3) * 10));
                    WszystkoOdNowa();
                }
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Graphics G = Graphics.FromImage(Rysunek);
            Pen mojePiorko = new Pen(Color.Red);
            G.Clear(Color.White);
            for (int i = 0; i < iloscPol; i++)
            {
                for (int j = 0; j < iloscPol; j++)
                {
                    Rectangle rec = new Rectangle(i * szerokoscPola, j * wysokoscPola, szerokoscPola, wysokoscPola);
                    SolidBrush brush;
                    if ((j+i) % 2 == 0)
                        brush = new SolidBrush(Color.Black);
                    else
                        brush = new SolidBrush(Color.FromArgb(10, 10, 10));
                    G.FillRectangle(brush, rec);
                }
            }
            RuchWeza(waz);
            //Rysuje mysz
            Rectangle myszka = new Rectangle(mysz[0] +szerokoscPola /4, mysz[1], szerokoscPola / 2, wysokoscPola);
            LinearGradientBrush mybrush = new LinearGradientBrush(myszka, Color.White, Color.YellowGreen, LinearGradientMode.ForwardDiagonal);
            G.FillRectangle(mybrush, myszka);
            //Punkty
            label1.Text = ((DlugoscWeza(waz) - 3) * 10).ToString();
            //this.Text = DlugoscWeza(waz).ToString();
            //Rysowanie weza
            for (int i = 0; i < DlugoscWeza(waz); i++)
            {
                Rectangle rec;
                if (i == 0)
                    rec = new Rectangle(waz[i].polX, waz[i].polY, szerokoscPola, wysokoscPola);
                else
                    rec = new Rectangle(waz[i].polX + 2, waz[i].polY + 2, szerokoscPola - 4, wysokoscPola - 4);
                    
                GraphicsPath gp = new GraphicsPath();
                gp.AddEllipse(rec);
                PathGradientBrush pGB = new PathGradientBrush(gp);
                pGB.CenterPoint = new Point(waz[i].polX + (szerokoscPola / 3), waz[i].polY + (wysokoscPola / 2));
                pGB.CenterColor = Color.Yellow;
                pGB.SurroundColors = new Color[1] { Color.Black };
                G.FillRectangle(pGB, rec);
            }
            pictureBox1.Image = Rysunek;
            G.Dispose();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
                if(biezacyKierunek != kierunek.Dol)
                    biezacyKierunek = kierunek.Gora;
            if (e.KeyCode == Keys.Down)
                if (biezacyKierunek != kierunek.Gora)
                    biezacyKierunek = kierunek.Dol;
            if (e.KeyCode == Keys.Right)
                if (biezacyKierunek != kierunek.Lewo)
                    biezacyKierunek = kierunek.Prawo;
            if (e.KeyCode == Keys.Left)
                if (biezacyKierunek != kierunek.Prawo)
                    biezacyKierunek = kierunek.Lewo;
            if (e.KeyCode == Keys.Escape)
                this.Close();
        }
    }
}
