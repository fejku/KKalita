﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;

namespace AI_01
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string aksjomat;
        public string[] cos_tam = new string[10];
        public string[] reg = new string[4];
        public string produkcja;
        public char[] symbol = new char[4];

        public double delta, dlugosc;
        public double il_przepisan;
        public double[] red = new double[2];

        List<double> f_x1 = new List<double>();
        List<double> f_x2 = new List<double>();
        List<double> f_y1 = new List<double>();
        List<double> f_y2 = new List<double>();
        List<double> f_alfa = new List<double>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            aksjomat = textBox2.Text;

            //F f + -
            cos_tam[0] = textBox5.Text;
            cos_tam[1] = textBox6.Text;
            cos_tam[2] = textBox7.Text;
            cos_tam[3] = textBox8.Text;

            //Reguly przepisania dla dodatkow symboli
            cos_tam[4] = textBox11.Text;
            cos_tam[5] = textBox12.Text;
            cos_tam[6] = textBox13.Text;
            cos_tam[7] = textBox14.Text;

            //[ ]
            cos_tam[8] = textBox24.Text;
            cos_tam[9] = textBox25.Text;

            //Reguly do rysowania dla dodatkowych symboli
            reg[0] = textBox20.Text;
            reg[1] = textBox21.Text;
            reg[2] = textBox22.Text;
            reg[3] = textBox23.Text;

            //Dodatkowe symbole
            symbol[0] = Char.Parse(textBox15.Text);
            symbol[1] = Char.Parse(textBox16.Text);
            symbol[2] = Char.Parse(textBox17.Text);
            symbol[3] = Char.Parse(textBox18.Text);

            il_przepisan = Int32.Parse(textBox9.Text);

            for (int j = 0; j < il_przepisan; j++)
            {
                produkcja = "";
                for (int i = 0; i < aksjomat.Length; i++)
                {
                    switch (aksjomat[i])
                    {
                        case 'F':
                            if (textBox5.Text == "")
                                produkcja += 'F';
                            else
                                produkcja += cos_tam[0];
                            break;
                        case 'f':
                            if (textBox6.Text == "")
                                produkcja += 'f';
                            else
                                produkcja += cos_tam[1];
                            break;
                        case '+':
                            if (textBox7.Text == "")
                                produkcja += '+';
                            else
                                produkcja += cos_tam[2];
                            break;
                        case '-':
                            if (textBox8.Text == "")
                                produkcja += '-';
                            else
                                produkcja += cos_tam[3];
                            break;
                        case '[':
                            if (textBox24.Text == "")
                                produkcja += '[';
                            else
                                produkcja += cos_tam[8];
                            break;
                        case ']':
                            if (textBox25.Text == "")
                                produkcja += ']';
                            else
                                produkcja += cos_tam[9];
                            break;
                    }
                    if (aksjomat[i] == symbol[0])
                    {
                        if (textBox11.Text == "")
                            produkcja += symbol[0];
                        else
                            produkcja += cos_tam[4];
                    }
                    if (aksjomat[i] == symbol[1])
                    {
                        if (textBox12.Text == "")
                            produkcja += symbol[1];
                        else
                            produkcja += cos_tam[5];
                    }
                    if (aksjomat[i] == symbol[2])
                    {
                        if (textBox13.Text == "")
                            produkcja += symbol[2];
                        else
                            produkcja += cos_tam[6];
                    }
                    if (aksjomat[i] == symbol[3])
                    {
                        if (textBox14.Text == "")
                            produkcja += symbol[3];
                        else
                            produkcja += cos_tam[7];
                    }
                }
                aksjomat = produkcja;
            }
            textBox10.Text = produkcja;
            produkcja = "";
            for (int i = 0; i < aksjomat.Length; i++)
            {
                switch (aksjomat[i])
                {
                    case 'F':
                        produkcja += 'F';
                        break;
                    case 'f':
                        produkcja += 'f';
                        break;
                    case '+':
                        produkcja += '+';
                        break;
                    case '-':
                        produkcja += '-';
                        break;
                    case '[':
                        produkcja += '[';
                        break;
                    case ']':
                        produkcja += ']';
                        break;
                }
                if (aksjomat[i] == symbol[0])
                {
                    if (textBox20.Text == "")
                        produkcja += symbol[0];
                    else
                        produkcja += reg[0];
                }
                if (aksjomat[i] == symbol[1])
                {
                    if (textBox21.Text == "")
                        produkcja += symbol[1];
                    else
                        produkcja += reg[1];
                }
                if (aksjomat[i] == symbol[2])
                {
                    if (textBox22.Text == "")
                        produkcja += symbol[2];
                    else
                        produkcja += reg[2];
                }
                if (aksjomat[i] == symbol[3])
                {
                    if (textBox23.Text == "")
                        produkcja += symbol[3];
                    else
                        produkcja += reg[3];
                }
            }
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Rysunek r1 = new Rysunek();
            r1.Show();

            dlugosc = Double.Parse(textBox4.Text);
            delta = Double.Parse(textBox3.Text);
            red[0] = Double.Parse(textBox1.Text);
            red[1] = Double.Parse(textBox19.Text);

            r1.textBox1.Text = produkcja;

            dlugosc *= Math.Pow(red[0] / red[1], il_przepisan);
            //double x1 = 250, x2 = 250, y1 = 250, y2 = 250;
            //double alfa = 0;
            int nr_zaglebienia = 0;
            //List<double> s_x = new List<double>(), s_y = new List<double>(), s_alfa = new List<double>();

            f_x1 = new List<double>();
            f_x2 = new List<double>();
            f_y1 = new List<double>();
            f_y2 = new List<double>();
            f_alfa = new List<double>();
            //s_x.Add(x1);
            //s_y.Add(y1);
            //s_alfa.Add(alfa);
            f_x1.Add(250);
            f_x2.Add(250);
            f_y1.Add(500);
            f_y2.Add(500);
            f_alfa.Add(Double.Parse(textBox26.Text));
            Line myLine;
            for (int i = 0; i < produkcja.Length; i++)
            {
                switch (produkcja[i])
                {
                    case 'F':
                        //s_x[nr_zaglebienia] = x2;
                        //x1 = s_x.Last();
                        ////x1 = x2;
                        //x2 = s_x[nr_zaglebienia] + dlugosc * Math.Cos(Math.PI / 180 * alfa);
                        ////x2 += dlugosc * Math.Cos(Math.PI / 180 * alfa);
                        //s_y[nr_zaglebienia] = y2;
                        //y1 = s_y.Last();
                        ////y1 = y2;
                        //y2 = s_y[nr_zaglebienia] + dlugosc * Math.Sin(Math.PI / 180 * alfa);
                        ////y2 += dlugosc * Math.Sin(Math.PI / 180 * alfa);

                        f_x1[nr_zaglebienia] = f_x2[nr_zaglebienia];
                        f_x2[nr_zaglebienia] += dlugosc * Math.Cos(Math.PI / 180 * f_alfa[nr_zaglebienia]);
                        f_y1[nr_zaglebienia] = f_y2[nr_zaglebienia];
                        f_y2[nr_zaglebienia] += dlugosc * Math.Sin(Math.PI / 180 * f_alfa[nr_zaglebienia]);

                        myLine = new Line();
                        myLine.Stroke = System.Windows.Media.Brushes.Black;
                        myLine.HorizontalAlignment = HorizontalAlignment.Left;
                        myLine.VerticalAlignment = VerticalAlignment.Top;
                        myLine.StrokeThickness = 2;
                        myLine.X1 = f_x1[nr_zaglebienia];
                        myLine.Y1 = f_y1[nr_zaglebienia];
                        myLine.X2 = f_x2[nr_zaglebienia];
                        myLine.Y2 = f_y2[nr_zaglebienia];
                        r1.grid1.Children.Add(myLine);
                        break;
                    case 'f':
                        //s_x[nr_zaglebienia] = x2;
                        //x1 = s_x.Last();
                        ////x1 = x2;
                        //x2 = s_x[nr_zaglebienia] + dlugosc * Math.Cos(Math.PI / 180 * alfa);
                        ////x2 += dlugosc * Math.Cos(Math.PI / 180 * alfa);
                        //s_y[nr_zaglebienia] = y2;
                        //y1 = s_y.Last();
                        ////y1 = y2;
                        //y2 = s_y[nr_zaglebienia] + dlugosc * Math.Sin(Math.PI / 180 * alfa);
                        ////y2 += dlugosc * Math.Sin(Math.PI / 180 * alfa);

                        f_x1[nr_zaglebienia] = f_x2[nr_zaglebienia];
                        f_x2[nr_zaglebienia] += dlugosc * Math.Cos(Math.PI / 180 * f_alfa[nr_zaglebienia]);
                        f_y1[nr_zaglebienia] = f_y2[nr_zaglebienia];
                        f_y2[nr_zaglebienia] += dlugosc * Math.Cos(Math.PI / 180 * f_alfa[nr_zaglebienia]);

                        break;
                    case '+':
                        f_alfa[nr_zaglebienia] -= delta;
                        break;
                    case '-':
                        f_alfa[nr_zaglebienia] += delta;
                        break;
                    case '[':
                        //s_x.Add(x1);
                        //s_y.Add(y1);
                        //s_alfa.Add(alfa);
                        f_x1.Add(f_x1[nr_zaglebienia]);
                        f_x2.Add(f_x2[nr_zaglebienia]);
                        f_y1.Add(f_y1[nr_zaglebienia]);
                        f_y2.Add(f_y2[nr_zaglebienia]);
                        f_alfa.Add(f_alfa[nr_zaglebienia]);
                        nr_zaglebienia++;
                        break;
                    case ']':
                        f_x1.RemoveAt(nr_zaglebienia);
                        f_x2.RemoveAt(nr_zaglebienia);
                        f_y1.RemoveAt(nr_zaglebienia);
                        f_y2.RemoveAt(nr_zaglebienia);
                        f_alfa.RemoveAt(nr_zaglebienia);
                        //s_x.RemoveAt(nr_zaglebienia);
                        //s_y.RemoveAt(nr_zaglebienia);
                        //s_alfa.RemoveAt(nr_zaglebienia);
                        nr_zaglebienia--;
                        break;
                }
            }
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "Struktura|*.txt";
            saveFileDialog1.Title = "Save an Structure File";
            saveFileDialog1.ShowDialog();

            if (saveFileDialog1.FileName != "")
            {
                FileStream plik = (FileStream)saveFileDialog1.OpenFile();
                StreamWriter zapisuj = new StreamWriter(plik);
                zapisuj.WriteLine(textBox2.Text);
                zapisuj.WriteLine(textBox1.Text);
                zapisuj.WriteLine(textBox19.Text);
                zapisuj.WriteLine(textBox3.Text);
                zapisuj.WriteLine(textBox4.Text);
                zapisuj.WriteLine(textBox5.Text);
                zapisuj.WriteLine(textBox6.Text);
                zapisuj.WriteLine(textBox7.Text);
                zapisuj.WriteLine(textBox8.Text);

                zapisuj.WriteLine(textBox24.Text);
                zapisuj.WriteLine(textBox25.Text);

                zapisuj.WriteLine(textBox15.Text);
                zapisuj.WriteLine(textBox11.Text);
                zapisuj.WriteLine(textBox20.Text);

                zapisuj.WriteLine(textBox16.Text);
                zapisuj.WriteLine(textBox12.Text);
                zapisuj.WriteLine(textBox21.Text);

                zapisuj.WriteLine(textBox17.Text);
                zapisuj.WriteLine(textBox13.Text);
                zapisuj.WriteLine(textBox22.Text);

                zapisuj.WriteLine(textBox18.Text);
                zapisuj.WriteLine(textBox14.Text);
                zapisuj.WriteLine(textBox23.Text);

                zapisuj.WriteLine(textBox9.Text);

                zapisuj.WriteLine(textBox26.Text);

                zapisuj.Close();
                plik.Close();
            }
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.DefaultExt = ".txt";
            dlg.Filter = "Struktura|*.txt";

            string text = string.Empty;
            if (dlg.ShowDialog() == true)
            {
                string filePath = dlg.FileName;
                StreamReader streamReader = new StreamReader(filePath);

                textBox2.Text = streamReader.ReadLine();
                textBox1.Text = streamReader.ReadLine();
                textBox19.Text = streamReader.ReadLine();
                textBox3.Text = streamReader.ReadLine();
                textBox4.Text = streamReader.ReadLine();
                textBox5.Text = streamReader.ReadLine();
                textBox6.Text = streamReader.ReadLine();
                textBox7.Text = streamReader.ReadLine();
                textBox8.Text = streamReader.ReadLine();

                textBox24.Text = streamReader.ReadLine();
                textBox25.Text = streamReader.ReadLine();

                textBox15.Text = streamReader.ReadLine();
                textBox11.Text = streamReader.ReadLine();
                textBox20.Text = streamReader.ReadLine();

                textBox16.Text = streamReader.ReadLine();
                textBox12.Text = streamReader.ReadLine();
                textBox21.Text = streamReader.ReadLine();

                textBox17.Text = streamReader.ReadLine();
                textBox13.Text = streamReader.ReadLine();
                textBox22.Text = streamReader.ReadLine();

                textBox18.Text = streamReader.ReadLine();
                textBox14.Text = streamReader.ReadLine();
                textBox23.Text = streamReader.ReadLine();

                textBox9.Text = streamReader.ReadLine();

                textBox26.Text = streamReader.ReadLine();

                streamReader.Close();
            }
        }
    }
}