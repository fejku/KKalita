﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;

namespace Kod_avast
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            byte[] reqHTML;
            wc.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            reqHTML = wc.DownloadData(textBox1.Text); // tutaj wyskakuje blad
            UTF8Encoding objUTF8 = new UTF8Encoding();
            //Console.Write(objUTF8.GetString(reqHTML));
            string pomoc = objUTF8.GetString(reqHTML);
            int poczatek = pomoc.IndexOf("<p>");
            int koniec = pomoc.IndexOf("</p>", poczatek);
            pomoc = pomoc.Substring(poczatek + 3, (koniec - poczatek) - 3);
            pomoc = pomoc.Replace("******", "\r\n");
            pomoc = pomoc.Replace("</br>", "\r\n");
            textBox2.Text = pomoc;
        }
    }
}
