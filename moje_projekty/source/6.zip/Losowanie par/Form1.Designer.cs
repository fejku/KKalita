﻿namespace Losowanie_par
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.b_Dodaj = new System.Windows.Forms.Button();
            this.b_Losuj = new System.Windows.Forms.Button();
            this.tb_Dodaj = new System.Windows.Forms.TextBox();
            this.lb_ListaGraczy = new System.Windows.Forms.ListBox();
            this.b_Usun = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.drabinkaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zwykłaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oProgramieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // b_Dodaj
            // 
            this.b_Dodaj.Location = new System.Drawing.Point(12, 27);
            this.b_Dodaj.Name = "b_Dodaj";
            this.b_Dodaj.Size = new System.Drawing.Size(75, 23);
            this.b_Dodaj.TabIndex = 0;
            this.b_Dodaj.Text = "Dodaj";
            this.b_Dodaj.UseVisualStyleBackColor = true;
            this.b_Dodaj.Click += new System.EventHandler(this.b_Dodaj_Click);
            // 
            // b_Losuj
            // 
            this.b_Losuj.Location = new System.Drawing.Point(512, 496);
            this.b_Losuj.Name = "b_Losuj";
            this.b_Losuj.Size = new System.Drawing.Size(314, 23);
            this.b_Losuj.TabIndex = 1;
            this.b_Losuj.Text = "Losuj";
            this.b_Losuj.UseVisualStyleBackColor = true;
            this.b_Losuj.Click += new System.EventHandler(this.b_Losuj_Click);
            // 
            // tb_Dodaj
            // 
            this.tb_Dodaj.Location = new System.Drawing.Point(12, 56);
            this.tb_Dodaj.Name = "tb_Dodaj";
            this.tb_Dodaj.Size = new System.Drawing.Size(119, 20);
            this.tb_Dodaj.TabIndex = 2;
            this.tb_Dodaj.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Dodaj_KeyPress);
            // 
            // lb_ListaGraczy
            // 
            this.lb_ListaGraczy.FormattingEnabled = true;
            this.lb_ListaGraczy.Location = new System.Drawing.Point(12, 82);
            this.lb_ListaGraczy.Name = "lb_ListaGraczy";
            this.lb_ListaGraczy.Size = new System.Drawing.Size(119, 407);
            this.lb_ListaGraczy.TabIndex = 3;
            // 
            // b_Usun
            // 
            this.b_Usun.Location = new System.Drawing.Point(12, 496);
            this.b_Usun.Name = "b_Usun";
            this.b_Usun.Size = new System.Drawing.Size(75, 23);
            this.b_Usun.TabIndex = 4;
            this.b_Usun.Text = "Usuń";
            this.b_Usun.UseVisualStyleBackColor = true;
            this.b_Usun.Click += new System.EventHandler(this.b_Usun_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(145, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(681, 462);
            this.panel1.TabIndex = 5;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.drabinkaToolStripMenuItem,
            this.oProgramieToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(838, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // drabinkaToolStripMenuItem
            // 
            this.drabinkaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zwykłaToolStripMenuItem,
            this.kOToolStripMenuItem});
            this.drabinkaToolStripMenuItem.Name = "drabinkaToolStripMenuItem";
            this.drabinkaToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.drabinkaToolStripMenuItem.Text = "Drabinka";
            // 
            // zwykłaToolStripMenuItem
            // 
            this.zwykłaToolStripMenuItem.Name = "zwykłaToolStripMenuItem";
            this.zwykłaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.zwykłaToolStripMenuItem.Text = "Zwykła";
            // 
            // kOToolStripMenuItem
            // 
            this.kOToolStripMenuItem.Name = "kOToolStripMenuItem";
            this.kOToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.kOToolStripMenuItem.Text = "2KO";
            // 
            // oProgramieToolStripMenuItem
            // 
            this.oProgramieToolStripMenuItem.Name = "oProgramieToolStripMenuItem";
            this.oProgramieToolStripMenuItem.Size = new System.Drawing.Size(86, 20);
            this.oProgramieToolStripMenuItem.Text = "O programie";
            this.oProgramieToolStripMenuItem.Click += new System.EventHandler(this.oProgramieToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(838, 530);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.b_Usun);
            this.Controls.Add(this.lb_ListaGraczy);
            this.Controls.Add(this.tb_Dodaj);
            this.Controls.Add(this.b_Losuj);
            this.Controls.Add(this.b_Dodaj);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Drabinka turniejowa made by Fejq";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button b_Dodaj;
        private System.Windows.Forms.Button b_Losuj;
        private System.Windows.Forms.TextBox tb_Dodaj;
        private System.Windows.Forms.ListBox lb_ListaGraczy;
        private System.Windows.Forms.Button b_Usun;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem drabinkaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zwykłaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oProgramieToolStripMenuItem;
    }
}

