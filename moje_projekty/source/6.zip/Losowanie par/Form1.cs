﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace Losowanie_par
{
    public partial class Form1 : Form
    {
        const int dlugosc_lini = 100;
        const int wysokosc_miedzy_liniami = 50;
        const int odstep = 20;

        Random random = new Random();
        int [] kolejnosc;
        bool losuj = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void b_Dodaj_Click(object sender, EventArgs e)
        {
            if (tb_Dodaj.Text != "")
            {
                lb_ListaGraczy.Items.Add(tb_Dodaj.Text);
                tb_Dodaj.Text = "";
            }
        }

        private void b_Usun_Click(object sender, EventArgs e)
        {
            lb_ListaGraczy.Items.Remove(lb_ListaGraczy.SelectedItem);
            lb_ListaGraczy.SelectedIndex = lb_ListaGraczy.Items.Count - 1;
        }

        private void tb_Dodaj_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == 13)
                if (tb_Dodaj.Text != "")
                {
                    lb_ListaGraczy.Items.Add(tb_Dodaj.Text);
                    tb_Dodaj.Text = "";
                }
        }

        private void Losuj()
        {
            int liczba;
            int[] tablica = new int[lb_ListaGraczy.Items.Count];
            kolejnosc = new int[tablica.Length];
            for (int i = 0; i < tablica.Length; i++)
                tablica[i] = i;
            for (int i = 0; i < tablica.Length; i++)
            {
                do
                {
                    liczba = random.Next(0, tablica.Length);
                } while (tablica[liczba] < 0);
                tablica[liczba] = -1;
                kolejnosc[i] = liczba;
            }
            
                losuj = true;
            panel1.Refresh();
        }

        private void b_Losuj_Click(object sender, EventArgs e)
        {
            if (lb_ListaGraczy.Items.Count > 2)
                Losuj();
            else
                MessageBox.Show("Podaj wiecej niż dwa elementy!");
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            int pom = 1;
            //Przeddrabinka
            bool przed = false;
            if (lb_ListaGraczy.Items.Count > 2)
            {
                if (losuj == true)
                {
                    Graphics g = e.Graphics;
                    Pen pen = new Pen(Color.Black);
                    Font font = new Font("Arial", 12, FontStyle.Regular);
                    Brush brush = new SolidBrush(System.Drawing.Color.Black);
                    panel1.AutoScroll = true;
                    panel1.AutoScrollMinSize = new Size(10000, kolejnosc.Length * 100);
                    //Tranformacja alby przy przesuwaniu scrolem obraz nie znikal
                    g.TranslateTransform(panel1.AutoScrollPosition.X, panel1.AutoScrollPosition.Y);

                    //Sprawdzenie do jakiej wielokrotnosci 2 najblizej 
                    do
                    {
                        pom *= 2;
                    } while (pom <= kolejnosc.Length);
                    pom /= 2;
                    //Wybranie ile osob jest wiecej niz potrzeba do drabinki
                    pom = kolejnosc.Length - pom;
                    //Połączenie w pary
                    pom *= 2;
                    int ilosc_iteracji = kolejnosc.Length - (pom / 2);
                    int pom1 = 1, pom2 = 0;
                    do
                    {
                        pom1 *= 2;
                        pom2++;
                    } while (pom1 != ilosc_iteracji);
                    ilosc_iteracji = pom2;

                    //Rysowanie w kazdym stopniu 2x mniej lini
                    int zmienna2 = 1;
                    //Odleglosc miedzy poszczegolnymi liniami
                    int pr = 50;
                    //Przesuniecie w kolejnych stopniach
                    int pp = 0;
                    //Jezeli sa jakies nadmiarowe osoby
                    if (pom > 0)
                    {
                        //MessageBox.Show(ilosc_iteracji.ToString());
                        //panel1.AutoScrollMinSize = new Size((ilosc_iteracji * dlugosc_lini), ((ilosc_iteracji + 1) * 100 * 2));
                        pr = 100;
                        przed = true;
                        //Narysuj przeddrabinke jezeli liczba osob nie jest wielokrotnoscia 2
                        for (int i = 0; i < pom; i++)
                        {
                            //Rysowanie poziomych lini
                            g.DrawLine(pen, odstep, odstep + (i * wysokosc_miedzy_liniami), odstep + dlugosc_lini, odstep + (i * wysokosc_miedzy_liniami));
                            //Wypisanie nazwy zawodnika
                            g.DrawString(lb_ListaGraczy.Items[kolejnosc[i]].ToString(), font, brush, odstep, (i * wysokosc_miedzy_liniami));
                            //Co druga linia pionowa
                            if (i % 2 == 0)
                            {
                                //Jezeli ostani jest nieparzysty nie rysuj lini pionowej
                                //if(i != (kolejnosc.Length - 1)) //Nie bedzie takiej mozliwosci zostawiam na przyszlosc
                                //Rysowanie lini pionowej
                                g.DrawLine(pen, (odstep + dlugosc_lini), odstep + (i * wysokosc_miedzy_liniami), (odstep + dlugosc_lini), (odstep + wysokosc_miedzy_liniami) + (i * wysokosc_miedzy_liniami));
                            }
                        }
                        for (int i = 1; i < (ilosc_iteracji + 2); i++)
                        {
                            //MessageBox.Show(ilosc_iteracji.ToString());
                            for (int j = 0; j < Math.Pow(2, ilosc_iteracji); j++)
                            {
                                if ((i == 1) && (j >= pom / 2))
                                    g.DrawString(lb_ListaGraczy.Items[kolejnosc[j + (pom / 2)]].ToString(), font, brush, 20 + (i * 100), ((j * pr) / zmienna2) + pp + 25);
                                if (j % zmienna2 == 0)
                                {
                                    //MessageBox.Show(pom.ToString());
                                    g.DrawLine(pen, 20 + (i * 100), 20 + ((j * pr) / zmienna2) + pp + 25, 120 + (i * 100), 20 + ((j * pr) / zmienna2) + pp + 25);
                                    if (j % (zmienna2 * 2) == 0)
                                    {
                                        //Jezeli ostania linie to nie rysuj lini pionowej x = max_i - 1
                                        if (i < (ilosc_iteracji + 1))
                                            g.DrawLine(pen, 120 + (i * 100), 20 + ((j * pr) / zmienna2) + pp + 25, 120 + (i * 100), 20 + ((j * pr) / zmienna2) + pp + pr + 25);
                                    }
                                }
                            }
                            zmienna2 *= 2;
                            pp = pp + pr / 2;
                            pr *= 2;
                        }
                    }
                    else
                    {
                        panel1.AutoScrollMinSize = new Size((ilosc_iteracji * dlugosc_lini), (kolejnosc.Length * wysokosc_miedzy_liniami));
                        for (int i = 0; i < (ilosc_iteracji + 1); i++)
                        {
                            for (int j = 0; j < Math.Pow(2, ilosc_iteracji); j++)
                            {
                                if (j % zmienna2 == 0)
                                {
                                    if (i == 0)
                                        g.DrawString(lb_ListaGraczy.Items[kolejnosc[j]].ToString(), font, brush, 20 + (i * 100), ((j * pr) / zmienna2) + pp);
                                    g.DrawLine(pen, 20 + (i * 100), 20 + ((j * pr) / zmienna2) + pp, 120 + (i * 100), 20 + ((j * pr) / zmienna2) + pp);
                                    if (j % (zmienna2 * 2) == 0)
                                    {
                                        //Jezeli ostania linie to nie rysuj lini pionowej x = max_i - 1
                                        if (i < (ilosc_iteracji))
                                            g.DrawLine(pen, 120 + (i * 100), 20 + ((j * pr) / zmienna2) + pp, 120 + (i * 100), 20 + ((j * pr) / zmienna2) + pp + pr);
                                    }
                                }
                            }
                            zmienna2 *= 2;
                            pp = pp + pr / 2;
                            pr *= 2;
                        }
                    }
                }
            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            float _zoom = 1.0f;
            //Creates the drawing matrix with the right zoom;
            Matrix mx = new Matrix(_zoom, 0, 0, _zoom, 0, 0);
            //pans it according to the scroll bars
            mx.Translate(this.AutoScrollPosition.X * (1.0f / _zoom), this.AutoScrollPosition.Y * (1.0f / _zoom));
            //inverts it
            mx.Invert();

            //uses it to transform the current mouse position
            Point[] pa = new Point[] { new Point(e.X, e.Y) };
            mx.TransformPoints(pa);
            Form mf = this.FindForm();
            mf.Text = "Drabinka turniejowa made by Fejq '" + pa[0].X.ToString() + "; " + pa[0].Y.ToString() + "'";
        }

        private void oProgramieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
        }
    }
}
