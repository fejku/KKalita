﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Globalization;

namespace Przerwy
{
    public partial class Form1 : Form
    {
        public struct Cwiczenie
        {
            public DateTime data;
            public String nazwa_cwiczenia;
            public int ilosc_serii;
            public int czas_przerwy;
            public int[] ilosc_powtorzen;
        }

        public List<Cwiczenie> cwiczenie = new List<Cwiczenie>();
        public List<Cwiczenie> dzisiejsze_cwiczenia = new List<Cwiczenie>();
        public DateTime czas;

        public Form1()
        {
            InitializeComponent();
        }

        public String CzasPrzerwyString(int czas)
        {
            String czas_przerwy;
            czas_przerwy = (czas / 60).ToString() + ":" + (czas % 60).ToString();
            if (czas < 600)
                czas_przerwy = "0" + czas_przerwy;
            //Blad powinno dodawac do przedostatniej a nie na koniec
            if ((czas % 60) < 10)
                czas_przerwy += "0";
            return czas_przerwy;
        }

        public bool PobierzDane()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Dziennik ćwiczeń|*.prz";
            ofd.ShowDialog();
            if (ofd.FileName != "")
            {
                FileStream plik = new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read);
                StreamReader sr = new StreamReader(plik);
                String linia;
                Cwiczenie cw;
                while ((linia = sr.ReadLine()) != null)
                {
                    String[] wyrazy = linia.Split(' ');
                    String[] data = wyrazy[0].Split('-');
                    cw.data = new DateTime(Int32.Parse(data[0]), Int32.Parse(data[1]), Int32.Parse(data[2]));
                    cw.nazwa_cwiczenia = wyrazy[1];
                    cw.ilosc_serii = Int32.Parse(wyrazy[2]);
                    cw.czas_przerwy = Int32.Parse(wyrazy[3]);
                    cw.ilosc_powtorzen = new int[cw.ilosc_serii];
                    for(int i = 0; i < cw.ilosc_serii; i++)
                        cw.ilosc_powtorzen[i] = Int32.Parse(wyrazy[4 + i]);
                    cwiczenie.Add(cw);
                }
            }
            if (cwiczenie.Count == 0)
                return false;
            else
                return true;
        }

        public void WczytajDzisiejszeCwiczenia()
        {
            comboBox1.Items.Clear();
            for (int i = 0; i < cwiczenie.Count; i++)
                if (cwiczenie[i].data == DateTime.Today)
                {
                    comboBox1.Items.Add(cwiczenie[i].nazwa_cwiczenia);
                    dzisiejsze_cwiczenia.Add(cwiczenie[i]);
                }
            comboBox1.SelectedIndex = 0;
        }

        public void WypiszCwiczenie()
        {
            lIloscSerii.Text = dzisiejsze_cwiczenia[comboBox1.SelectedIndex].ilosc_serii.ToString();
            lCzasPrzerwy.Text = CzasPrzerwyString(dzisiejsze_cwiczenia[comboBox1.SelectedIndex].czas_przerwy);
            lIloscPowtorzen.Text = dzisiejsze_cwiczenia[comboBox1.SelectedIndex].ilosc_powtorzen[0].ToString();
        }

        private void bWczytajPlik_Click(object sender, EventArgs e)
        {
            if (PobierzDane())
                bStart.Enabled = true;
            WczytajDzisiejszeCwiczenia();
            WypiszCwiczenie();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            WypiszCwiczenie();
            bStart.Enabled = true;
        }

        private void bStart_Click(object sender, EventArgs e)
        {
            czas = DateTime.ParseExact(lCzasPrzerwy.Text, "mm:ss", CultureInfo.InvariantCulture);
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            czas = czas.AddSeconds(-1);
            lCzasPrzerwy.Text = czas.ToString().Substring(14, 5);
            if (lCzasPrzerwy.Text.Equals("00:00"))
            {
                timer1.Enabled = false;
                lIloscSerii.Text = (Int32.Parse(lIloscSerii.Text) - 1).ToString();
                if (lIloscSerii.Text == "1")
                {
                    bStart.Enabled = false;
                    lCzasPrzerwy.Text = "MAX";
                    lIloscPowtorzen.Text = dzisiejsze_cwiczenia[comboBox1.SelectedIndex].ilosc_powtorzen[dzisiejsze_cwiczenia[comboBox1.SelectedIndex].ilosc_serii - 1].ToString();
                }
                else
                {
                    czas = DateTime.ParseExact(CzasPrzerwyString(dzisiejsze_cwiczenia[comboBox1.SelectedIndex].czas_przerwy), "mm:ss", CultureInfo.InvariantCulture);
                    lCzasPrzerwy.Text = czas.ToString().Substring(14, 5);
                    lIloscPowtorzen.Text = dzisiejsze_cwiczenia[comboBox1.SelectedIndex].ilosc_powtorzen[dzisiejsze_cwiczenia[comboBox1.SelectedIndex].ilosc_serii - Int32.Parse(lIloscSerii.Text)].ToString();
                }
            }
        }
    }
}
