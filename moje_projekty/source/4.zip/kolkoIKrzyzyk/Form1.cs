﻿using System;   
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace kolkoIKrzyzyk
{
    public partial class Form1 : Form
    {
        private Bitmap Rysunek = new Bitmap(300, 300);
        private int krok = 0;
        private int[] plansza = new int[9];
        private Random rnd = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RysujPlansze();
            ZerojPlansze();
            
        }

        private void ZerojPlansze()
        {
            for (int i = 0; i < 9; i++)
            {
                plansza[i] = 0;
            }
        }

        private void RysujPlansze()
        {
            Graphics G = Graphics.FromImage(Rysunek);
            Pen mojePiorko = new Pen(Color.Blue);
            
            G.Clear(Color.White);
            G.DrawLine(mojePiorko, 0, Rysunek.Height / 3, Rysunek.Width, Rysunek.Height / 3);
            G.DrawLine(mojePiorko, 0, (Rysunek.Height / 3) * 2, Rysunek.Width, (Rysunek.Height / 3) * 2);
            G.DrawLine(mojePiorko, Rysunek.Width / 3, 0, Rysunek.Width / 3, Rysunek.Height);
            G.DrawLine(mojePiorko, (Rysunek.Width / 3) * 2, 0, (Rysunek.Width / 3) * 2, Rysunek.Height);
            pictureBox1.Image = Rysunek;
            G.Dispose();
        }

        private int Sprawdzenie(int[] pl)
        {
            int wynik = 0 ;
            for (int i = 0; i < Math.Sqrt(pl.Length); i++)
            {
                wynik = pl[i * 3] + pl[(i * 3) + 1] + pl[(i * 3) + 2];
                if (wynik == 3)
                    return 1;
                if (wynik == 30)
                    return 2;
                wynik = pl[i] + pl[i + 3] + pl[i + 6];
                if (wynik == 3)
                    return 1;
                if (wynik == 30)
                    return 2;
            }
            wynik = pl[0] + pl[4] + pl[8];
            if (wynik == 3)
                return 1;
            if (wynik == 30)
                return 2;
            wynik = pl[2] + pl[4] + pl[6];
            if (wynik == 3)
                return 1;
            if (wynik == 30)
                return 2;
            return 0;
        }

        private bool wypisz(int[] pl, int kr)
        {
            if (Sprawdzenie(pl) == 1)
            {
                MessageBox.Show("Kólko wygrało");
                RysujPlansze();
                ZerojPlansze();
                krok = 0;
                return true;
            }
            if (Sprawdzenie(pl) == 2)
            {
                MessageBox.Show("Krzyzyk wygrał");
                RysujPlansze();
                ZerojPlansze();
                krok = 0;
                return true;
            }
            if ((Sprawdzenie(pl) == 0) && (kr > 8))
            {
                MessageBox.Show("Remis");
                RysujPlansze();
                ZerojPlansze();
                krok = 0;
                return true;
            }
            return false;
        }

        private int mojMinMax(int[] pl)
        {
            int pom;
            for (int i = 0; i < 9; i++)
            {
                if (pl[i] == 0)
                {
                    pl[i] = 10;
                    //Jezeli wygrywa komputer, wygraj
                    if (Sprawdzenie(pl) == 2)
                    {
                        pl[i] = 0;
                        return i;
                    }
                    pl[i] = 0;
                }
            }
            for (int i = 0; i < 9; i++)
            {
                if (pl[i] == 0)
                {
                    pl[i] = 1;
                    //Jezeli wygrywa komputer, wygraj
                    if (Sprawdzenie(pl) == 1)
                    {
                        pl[i] = 0;
                        return i;
                    }
                    pl[i] = 0;
                }
            }
            do
            {
                pom = rnd.Next(0, 9);
            } while (pl[pom] != 0);
            return pom;
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            int pom;
            if (plansza[(e.X / 100) + ((e.Y / 100) * 3)] == 0)
            {
                Graphics G = Graphics.FromImage(Rysunek);
                Pen mojePiorko = new Pen(Color.Black);

                //Rysowanie kolka
                G.DrawEllipse(mojePiorko, ((e.X / 100) * 100), ((e.Y / 100) * 100), 100, 100);
                plansza[(e.X / 100) + ((e.Y / 100) * 3)] = 1;
                krok++;

                pictureBox1.Image = Rysunek;

                if (!wypisz(plansza, krok))
                {
                    pom = mojMinMax(plansza);

                    //Rysowanie krzyzyka
                    G.DrawLine(mojePiorko, (pom % 3) * 100, ((pom / 3) * 100), (((pom % 3) * 100) + 100), (((pom / 3) * 100) + 100));
                    G.DrawLine(mojePiorko, (((pom % 3) * 100) + 100), ((pom / 3) * 100), ((pom % 3) * 100), (((pom / 3) * 100) + 100));
                    plansza[pom] = 10;
                    krok++;

                    pictureBox1.Image = Rysunek;

                    wypisz(plansza, krok);
                }
                G.Dispose();
            }
            else
                MessageBox.Show("Wybierz puste pole");
        }

    }
}
